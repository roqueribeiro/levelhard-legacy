﻿//Porta de publicacao
const PORT = 3000;

//Intervalo do monitor do banco
const INTERVAL = 1000; //6 segundos

//Informacoes da Session
const KEY = 'speechlesscookie';
const SECRET = 'codekey-speechless';
const EXPIRE = 3600000 * 3; //3 horas para expirar

//Modulos requeridos
var express = require('express')
  , cookieParser = require('cookie-parser')
  , expressSession = require('express-session')
  , app = express()
  , server = require('http').createServer(app)
  , io = require('socket.io').listen(server)
  , cookie = cookieParser(SECRET)
  , store = new expressSession.MemoryStore()
  , mysql = require('mysql')
  , bodyParser = require('body-parser')
  , compression = require('compression');
;

//Parametros de conexao com banco de dados
var pool = mysql.createPool({
    connectionLimit: 100,
    host: '127.0.0.1',
    user: 'root',
    password: '',
    database: 'bd_speechless',
    debug: false,
    multipleStatements: true
});

//Definicoes de rotas do ExpressJs
app.use(compression());
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookie);
app.use(expressSession({
    secret: SECRET,
    name: KEY,
    resave: true,
    saveUninitialized: true,
    store: store,
    cookie: {
        expires: new Date(Date.now() + EXPIRE),
        maxAge: EXPIRE
    }
}));

//Definicoes do cookie da sessao
io.use(function (socket, next) {
    var data = socket.request;
    cookie(data, {}, function (err) {
        var sessionID = data.signedCookies[KEY];
        store.get(sessionID, function (err, session) {
            if (err || !session) {
                return next(new Error('Acesso negado!'));
            } else {
                socket.handshake.session = session;
                return next();
            }
        });
    });
});

//Clear SQL INJECTION
var clearVariable = function (varReceived) {
    return varReceived.replace(/(['".*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}

//Rota para pagina inicial
app.get('/', function (req, res) {
    res.render('index');
});

app.post('/session', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    if (req.session.userid) {
        try {
            pool.getConnection(function (err, connection) {
                if (!err) {
                    //Altera status para online
                    connection.query('UPDATE TBL_SPL_USR SET SPL_USR_EST = 2 WHERE SPL_USR_COD = ' + req.session.userid, function (err, rows) {
                        connection.release();
                        if (!err) {
                            //Mostra no log de eventos do terminal
                            console.log('userConnected ' + req.session.userid + ' - ' + req.session.username);
                        }
                    });
                } else {
                    connection.release();
                    console.log(err);
                }
            });
        }
        catch (ex) {
            console.log(ex);
        }
    }
    res.send(JSON.stringify(req.session));
});

//Autenticacao do usuario -> retorno em json
app.post('/auth', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    try {
        pool.getConnection(function (err, connection) {
            if (!err) {
                //Procedimento de autorizacao de usuario
                connection.query("CALL SP_AUTH_LOGIN('" + clearVariable(req.body.user) + "','" + clearVariable(req.body.pass) + "')", function (err, rows) {
                    if (!err) {
                        switch (rows[0][0].AUTH_RETURN) {
                            case 0:
                                //Se usuario e senha estao corretos
                                //Grava na sessao do usuario
                                req.session.userid = rows[0][0].AUTH_USERID;
                                req.session.username = rows[0][0].AUTH_USERNAME;
                                req.session.usermsg = rows[0][0].AUTH_USERMSG;
                                req.session.userpic = rows[0][0].AUTH_USERPIC;
                                req.session.userlast = rows[0][0].AUTH_LASTSESSION;
                                //Retorno para formulario
                                res.send(JSON.stringify({
                                    auth_cod: 0,
                                    userid: rows[0][0].AUTH_USERID,
                                    username: rows[0][0].AUTH_USERNAME,
                                    usermsg: rows[0][0].AUTH_USERMSG,
                                    userpic: rows[0][0].AUTH_USERPIC,
                                    userlast: rows[0][0].AUTH_LASTSESSION
                                }));
                                break;
                            case 1:
                                //Se login nao estiver correto
                                connection.release();
                                console.log(rows[0][0]);
                                res.send(JSON.stringify({
                                    auth_cod: rows[0][0].AUTH_RETURN,
                                    auth_message: 'Houve um problema no procedimento de login. Tente novamente mais tarde.',
                                    auth_errinfo: rows[0][0].AUTH_MSG,
                                    auth_errcode: rows[0][0].AUTH_ERR,
                                }));
                                break;
                            case 2:
                                //Se login nao estiver correto
                                connection.release();
                                res.send(JSON.stringify({
                                    auth_cod: rows[0][0].AUTH_RETURN
                                }));
                                break;
                            case 3:
                                //Se senha esta incorreta
                                connection.release();
                                res.send(JSON.stringify({
                                    auth_cod: rows[0][0].AUTH_RETURN
                                }));
                                break;
                        }
                    } else {
                        //Se houve erros ao executar procedimento de login
                        connection.release();
                        console.log(err);
                        res.send(JSON.stringify({
                            auth_cod: 1,
                            auth_message: 'Houve um problema de comunicação com a base de dados. Tente novamente mais tarde.',
                            auth_errinfo: err.code,
                            auth_errcode: err.errno,
                        }));
                    }
                });
            } else {
                //Se houve erros ao se comunicar com banco de dados
                connection.release();
                console.log(err);
            }
        });
    }
    catch (ex) {
        console.log(ex);
    }
});

//Desconecta usuario da sessao atual
app.post('/logout', function (req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.session.destroy(function (err) { (err) ? console.log(err) : null; });
    res.send(JSON.stringify({ auth_cod: -1 }));
});

//Funcoes do websocket (Socket.IO)
io.sockets.on('connection', function (client) {

    var session = client.handshake.session;

    //Recebimento de mensagens
    client.on('toServer', function (data) {
        //Verifica usuario logado
        if (session.userid) {
            client.emit('toClient', data);
            client.broadcast.emit('toClient', data);
        }
    });

    //Monitora banco de dados em um intervalo especificado na variavel INTERVAL (segundos)
    setInterval(function () {
        //Verifica usuario logado
        if (session.userid) {
            pool.getConnection(function (err, connection) {
                if (!err) {
                    //Carrega lista de contatos
                    connection.query('SELECT * FROM TBL_SPL_USR INNER JOIN TBL_SPL_EST ON SPL_USR_EST = SPL_EST_COD WHERE SPL_USR_STS = 1 AND SPL_USR_COD <> ' + session.userid, function (err, rows) {
                        connection.release();
                        if (!err) {
                            if (rows.length > 0) {
                                var contact_list = [];
                                for (var i in rows) {
                                    contact_list.push(rows[i]);
                                }
                                client.emit('contactList', contact_list);
                            }
                        } else {
                            console.log(err);
                        }
                    });
                } else {
                    connection.release();
                    console.log(err);
                }
            });
        }
    }, INTERVAL);

    //Identifica desconexao de usuario
    client.on('disconnect', function () {
        if (session.userid) {
            pool.getConnection(function (err, connection) {
                if (!err) {
                    //Altera status para offline
                    connection.query('UPDATE TBL_SPL_USR SET SPL_USR_EST = 1 WHERE SPL_USR_COD = ' + session.userid, function (err, rows) {
                        connection.release();
                        if (!err) {
                            client.emit('userDisconnect', session.userid);
                            //Mostra no log de eventos do terminal
                            console.log('userDisconnect ' + session.userid + ' - ' + session.username);
                        } else {
                            console.log(err);
                        }
                    });
                } else {
                    connection.release();
                    console.log(err);
                }
            });
        }
    });

});

//Inicia servidor do software
server.listen(PORT, function () {
    console.log('Speechless iniciado na porta: ' + PORT);
});