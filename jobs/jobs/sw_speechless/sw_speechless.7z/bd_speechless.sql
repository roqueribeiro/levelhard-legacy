-- phpMyAdmin SQL Dump
-- version 4.5.0-beta1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 21-Set-2015 às 04:07
-- Versão do servidor: 5.6.25
-- PHP Version: 5.5.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bd_speechless`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_AUTH_LOGIN` (IN `VAR_USR_LOGIN` VARCHAR(50), IN `VAR_USR_PASS` VARCHAR(16))  BEGIN
	
    DECLARE ERR_CODE CHAR(5) DEFAULT '00000';
	DECLARE ERR_MESSAGE TEXT;
	DECLARE AUTH_PASS INT UNSIGNED DEFAULT 0;

	/*SE OCORRER ERROS*/
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 
			ERR_CODE = RETURNED_SQLSTATE, 
			ERR_MESSAGE = MESSAGE_TEXT;
		SELECT 
			1 AS AUTH_RETURN, 
            ERR_CODE AS AUTH_ERR, 
            ERR_MESSAGE AS AUTH_MSG;
		ROLLBACK;
	END;
    
    /*VALIDA LOGIN*/
    SELECT 1 INTO AUTH_PASS
    FROM
		TBL_SPL_USR
	WHERE
		SPL_USR_LGN = VAR_USR_LOGIN;
        
	/*SE LOGIN VALIDO*/
	IF AUTH_PASS <> 0 THEN
		
        SET AUTH_PASS = 0;
        
        /*VALIDA SENHA*/
        SELECT 1 INTO AUTH_PASS
		FROM
			TBL_SPL_USR
		WHERE
			SPL_USR_LGN = VAR_USR_LOGIN 
            AND SPL_USR_SNH = VAR_USR_PASS;
		
        /*SE SENHA VALIDA*/
		IF AUTH_PASS <> 0 THEN
        
			SET AUTH_PASS = 0;
        
			/*VALIDA STATUS ATIVO*/
			SELECT 1 INTO AUTH_PASS
			FROM
				TBL_SPL_USR
			WHERE
				SPL_USR_LGN = VAR_USR_LOGIN 
				AND SPL_USR_SNH = VAR_USR_PASS
                AND SPL_USR_STS = 1;
			
            /*SE STATUS ATIVO*/
			IF AUTH_PASS <> 0 THEN
				/*AUTORIZADO*/
                
                /*ATUALIZA STATUS PARA ONLINE*/
                UPDATE TBL_SPL_USR 
                SET SPL_USR_EST = (SELECT SPL_EST_COD FROM TBL_SPL_EST WHERE SPL_EST_NOM = 'ONLINE' LIMIT 1)
                WHERE
					SPL_USR_LGN = VAR_USR_LOGIN 
					AND SPL_USR_SNH = VAR_USR_PASS
					AND SPL_USR_STS = 1;
                
                /*MOSTRA INFORMACOES DA AUTENTICACAO*/
                SELECT
					0 AS AUTH_RETURN, 
                    SPL_USR_COD AS AUTH_USERID, 
                    SPL_USR_NOM AS AUTH_USERNAME,
                    SPL_USR_MSG AS AUTH_USERMSG,
                    SPL_USR_PIC AS AUTH_USERPIC,
                    SPL_USR_LSE AS AUTH_LASTSESSION
				FROM 
					TBL_SPL_USR 
				WHERE 
					SPL_USR_LGN = VAR_USR_LOGIN;
            ELSE
				/*STATUS INATIVO*/
				SELECT 4 AS AUTH_RETURN;
            END IF;			
        ELSE
			/*SENHA INVALIDA*/
			SELECT 3 AS AUTH_RETURN;
        END IF;
	ELSE
		/*LOGIN INVALIDO*/
		SELECT 2 AS AUTH_RETURN;
    END IF;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_CONTACT_LIST_ALL` (IN `VAR_USR_COD` INTEGER)  BEGIN
	
    DECLARE ERR_CODE CHAR(5) DEFAULT '00000';
	DECLARE ERR_MESSAGE TEXT;
	DECLARE AUTH_PASS INT UNSIGNED DEFAULT 0;

	/*SE OCORRER ERROS*/
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		GET DIAGNOSTICS CONDITION 1 
			ERR_CODE = RETURNED_SQLSTATE, 
			ERR_MESSAGE = MESSAGE_TEXT;
		SELECT 
			1 AS AUTH_RETURN, 
            ERR_CODE AS AUTH_ERR, 
            ERR_MESSAGE AS AUTH_MSG;
		ROLLBACK;
	END;
    
    SELECT * 
    FROM 
		TBL_SPL_USR 
	INNER JOIN 
		TBL_SPL_EST 
	ON 
		SPL_USR_EST = SPL_EST_COD 
	WHERE 
		SPL_USR_STS = 1 AND 
        SPL_USR_COD <> VAR_USR_COD;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_spl_ctl`
--

CREATE TABLE `tbl_spl_ctl` (
  `SPL_CTL_COD` int(11) NOT NULL COMMENT 'Código',
  `SPL_CTL_USR` int(11) NOT NULL COMMENT 'Usuário',
  `SPL_CTL_CON` int(11) NOT NULL COMMENT 'Contato',
  `SPL_CTL_CUR` tinyint(1) NOT NULL COMMENT 'Em conversa',
  `SPL_CTL_STS` tinyint(1) NOT NULL COMMENT 'Status'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Lista de contatos';

--
-- Extraindo dados da tabela `tbl_spl_ctl`
--

INSERT INTO `tbl_spl_ctl` (`SPL_CTL_COD`, `SPL_CTL_USR`, `SPL_CTL_CON`, `SPL_CTL_CUR`, `SPL_CTL_STS`) VALUES
(1, 1, 2, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_spl_est`
--

CREATE TABLE `tbl_spl_est` (
  `SPL_EST_COD` int(11) NOT NULL COMMENT 'Código',
  `SPL_EST_NOM` varchar(100) NOT NULL COMMENT 'Nome'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Status de usuário';

--
-- Extraindo dados da tabela `tbl_spl_est`
--

INSERT INTO `tbl_spl_est` (`SPL_EST_COD`, `SPL_EST_NOM`) VALUES
(3, 'AUSENTE'),
(4, 'OCUPADO'),
(1, 'OFFLINE'),
(2, 'ONLINE');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_spl_msg`
--

CREATE TABLE `tbl_spl_msg` (
  `SPL_MSG_COD` int(11) NOT NULL COMMENT 'Código',
  `SPL_MSG_UID` int(11) NOT NULL COMMENT 'Remetente',
  `SPL_MSG_RID` int(11) NOT NULL COMMENT 'Destinatario',
  `SPL_MSG_TXT` text NOT NULL COMMENT 'Mensagem',
  `SPL_MSG_REA` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Lido',
  `SPL_MSG_DTH` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data Hora Criação',
  `SPL_MSG_STS` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Status'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_spl_usr`
--

CREATE TABLE `tbl_spl_usr` (
  `SPL_USR_COD` int(11) NOT NULL COMMENT 'Código',
  `SPL_USR_NOM` varchar(255) NOT NULL COMMENT 'Nome',
  `SPL_USR_LGN` varchar(50) NOT NULL COMMENT 'Login',
  `SPL_USR_SNH` varchar(16) NOT NULL COMMENT 'Senha',
  `SPL_USR_MSG` varchar(255) NOT NULL DEFAULT 'Estou conversando com Speechless.' COMMENT 'Comentário',
  `SPL_USR_PIC` varchar(400) NOT NULL COMMENT 'Imagem',
  `SPL_USR_LSE` varchar(36) NOT NULL COMMENT 'Ultima Sessão',
  `SPL_USR_EST` int(11) NOT NULL DEFAULT '1' COMMENT 'Estado',
  `SPL_USR_DTH` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data Hora Criação',
  `SPL_USR_STS` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Status'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Usuários de sistema';

--
-- Extraindo dados da tabela `tbl_spl_usr`
--

INSERT INTO `tbl_spl_usr` (`SPL_USR_COD`, `SPL_USR_NOM`, `SPL_USR_LGN`, `SPL_USR_SNH`, `SPL_USR_MSG`, `SPL_USR_PIC`, `SPL_USR_LSE`, `SPL_USR_EST`, `SPL_USR_DTH`, `SPL_USR_STS`) VALUES
(1, 'Roque José Ribeiro da Silva Junior', 'roque.ribeiro', 'rb1234', 'Algo mudou?', '', '', 1, '2015-09-19 17:51:53', 1),
(2, 'Mario Costa', 'mario.costa', 'mc1234', 'Estou conversando com Speechless.', '', '', 2, '2015-09-19 17:51:53', 1),
(3, 'Maria José Galvão', 'maria.galvao', 'mg1234', 'Estou conversando com Speechless.', '', '', 2, '2015-09-19 17:51:53', 1),
(4, 'Usuário de Teste 1', 'usuario.1', 'u11234', 'Estou conversando com Speechless.', '', '', 1, '2015-09-19 17:51:53', 1),
(5, 'Usuário de Teste 2', 'usuario.2', 'u21234', 'Estou conversando com Speechless.', '', '', 1, '2015-09-19 17:51:53', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_spl_usr_log`
--

CREATE TABLE `tbl_spl_usr_log` (
  `SPL_ACS_COD` int(11) NOT NULL COMMENT 'Código',
  `SPL_ACS_USR` int(11) NOT NULL COMMENT 'Usuario',
  `SPL_ACS_NAV` varchar(11) NOT NULL COMMENT 'Navegador',
  `SPL_ACS_IPP` varchar(255) NOT NULL COMMENT 'Protocolo IP',
  `SPL_ACS_ACT` varchar(255) NOT NULL COMMENT 'Ação',
  `SPL_ACS_DTH` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Data Hora Criação'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_spl_ctl`
--
ALTER TABLE `tbl_spl_ctl`
  ADD PRIMARY KEY (`SPL_CTL_COD`);

--
-- Indexes for table `tbl_spl_est`
--
ALTER TABLE `tbl_spl_est`
  ADD PRIMARY KEY (`SPL_EST_COD`),
  ADD UNIQUE KEY `SPL_EST_COD` (`SPL_EST_COD`),
  ADD UNIQUE KEY `SPL_EST_NOM` (`SPL_EST_NOM`),
  ADD KEY `SPL_EST_NOM_2` (`SPL_EST_NOM`),
  ADD KEY `SPL_EST_COD_2` (`SPL_EST_COD`),
  ADD KEY `SPL_EST_COD_3` (`SPL_EST_COD`);

--
-- Indexes for table `tbl_spl_msg`
--
ALTER TABLE `tbl_spl_msg`
  ADD PRIMARY KEY (`SPL_MSG_COD`);

--
-- Indexes for table `tbl_spl_usr`
--
ALTER TABLE `tbl_spl_usr`
  ADD PRIMARY KEY (`SPL_USR_COD`),
  ADD UNIQUE KEY `SPL_USR_COD` (`SPL_USR_COD`),
  ADD UNIQUE KEY `SPL_USR_LGN` (`SPL_USR_LGN`),
  ADD KEY `SPL_USR_COD_2` (`SPL_USR_COD`),
  ADD KEY `SPL_USR_LGN_2` (`SPL_USR_LGN`);

--
-- Indexes for table `tbl_spl_usr_log`
--
ALTER TABLE `tbl_spl_usr_log`
  ADD PRIMARY KEY (`SPL_ACS_COD`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_spl_ctl`
--
ALTER TABLE `tbl_spl_ctl`
  MODIFY `SPL_CTL_COD` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Código', AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_spl_est`
--
ALTER TABLE `tbl_spl_est`
  MODIFY `SPL_EST_COD` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Código', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_spl_usr`
--
ALTER TABLE `tbl_spl_usr`
  MODIFY `SPL_USR_COD` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Código', AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
