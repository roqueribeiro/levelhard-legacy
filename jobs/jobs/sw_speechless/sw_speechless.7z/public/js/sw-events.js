﻿$(document).ready(function () {

    //Faz requisicao da permissao para envio de notificacoes desktop
    var Notification = window.Notification || window.mozNotification || window.webkitNotification;
    if (Notification) {
        Notification.requestPermission(function (permission) {
            if (permission !== "granted") {
                Notification.requestPermission();
            }
        });
    }
    else {
        $.swOpenDynamicModal({
            title: "<h4>Falta de recursos</h4>",
            content: 'O navegador que está utilizando não possuí a tecnologia de recepção de notificações.',
            buttons: {
                cancel: {
                    btntext: "Ok",
                    btnclass: "btn-link",
                    callback: function (element) {
                        $.swOpenDynamicModal({
                            closeid: $(element).data("id")
                        });
                    }
                }
            }
        });
    }

    //Definicoes da pagina para computadores
    if ($("body").width() > 600) {
        var defaults = {
            background: "#FFF",
            cursorcolor: "#455A64",
            cursorwidth: 8,
            cursorborder: "none",
            cursorborderradius: "0px",
            horizrailenabled: false,
            autohidemode: false,
            railpadding: { top: 0, right: 0, left: 0, bottom: 0 }
        };
        $("body > content > main").niceScroll(defaults);
        $("body > content > nav ul").niceScroll(defaults);
        $(".modal").niceScroll(defaults);
        $("body > content > main > #sw-messages content").niceScroll(defaults);
    }

    $("#sw-fullscreen").swGoToFullscreen();
    $("#sw-mainmenu").swOpenMainMenu();
    $("#sw-navtabs").swNavTabs();
    $("a").swNavWindows();

    $.cookie.json = true;
    //Variaveis da sessao
    var host = window.location.protocol + '//' + window.location.host;
    var userid;
    var username;
    var usermsg;
    var userpic;
    var userlast;
    var visibleinfo;

    var socketConnection = function () {

        //Conexao com o servidor de websocket (Socket.IO)
        var socket = io(host);

        //Define nome do usuario no menu lateral
        $('content nav header p').html(username + '<br /><small>' + usermsg + '</small>');

        //Define tempo para entrar em modo inativo (30 segundos)
        ifvisible.setIdleDuration(30);

        //Identifica estado de atividade atual do usuario no navegador
        ifvisible.on('statusChanged', function (e) { visibleinfo = e.status; });

        //Identifica inatividade do usuario em tela
        ifvisible.idle(function () { });

        //Identifica atividade do usuario em tela
        ifvisible.wakeup(function () { });

        var temp_msg = [];
        //Recebimento de mensagens do servidor para cliente (Socket.IO)
        socket.on('toClient', function (data) {

            //Cria um banco de dados temporario em cookie
            if (data.userto == userid || data.userid == userid) { temp_msg.push(data); }
            var temp_msg_filter = $.grep(temp_msg, function (element, index) {
                return element.userto == userid || element.userid == userid;
            });

            if ($.cookie('temp_msg_session')) {
                $.cookie('temp_msg_session', $.cookie('temp_msg_session').concat(temp_msg_filter[temp_msg_filter.length - 1]), { path: '/' });
            } else {
                $.cookie('temp_msg_session', temp_msg_filter, { path: '/' });
            }

            //Verifica tela atual para mostrar mensagens
            if (($('#sw-messages').attr('data-userid') == data.userid && data.userto == userid) ||
                data.userid == userid) {
                //Cria elemento caixa de mensagem
                $('<div>', {
                    'class': 'sw-message-line',
                    'html': $('<div>', {
                        'class': 'sw-message-box'
                    }).append($('<div>', {
                        'class': 'sw-message-photo'
                    })).append($('<div>', {
                        'class': 'sw-message-content'
                    }).append($('<div>', {
                        'class': 'sw-message-user',
                        'text': data.username
                    })).append($('<div>', {
                        'class': 'sw-message-text',
                        'text': data.message
                    })).append($('<div>', {
                        'class': 'sw-message-info',
                        'text': data.datetime
                    })))
                }).addClass(
                    (data.userid == userid) ? 'sw-message-align-right' : 'sw-message-align-left'
                ).appendTo('#sw-messages content');

                //Atualiza scrollbar ao atingir altura maxima
                $('#sw-messages content').scrollTop($('#sw-messages content')[0].scrollHeight);
                $('#sw-messages content').getNiceScroll().resize();

                //Efeito ao apresentar mensagem enviada ou recebida
                $('#sw-messages content > div:last').transition({
                    x: '-10%',
                    opacity: 0,
                    duration: 0
                }).transition({
                    x: '0%',
                    opacity: 1,
                    duration: 400,
                    easing: 'easeOutBack'
                });

                //Se janela minimizada
                if (visibleinfo == 'hidden') {
                    //Emite notificacao externa
                    $.swExternalNotification({
                        icon: '/img/logo/speechless-logo-64.png',
                        title: data.username,
                        body: data.message,
                        sound: true
                    });
                }
            }
            else if (data.userto == userid) {

                //Emite vibracao ao aparelho
                navigator.vibrate = navigator.vibrate || navigator.webkitVibrate || navigator.mozVibrate || navigator.msVibrate;
                if (navigator.vibrate) {
                    navigator.vibrate([600]);
                }

                //Adiciona classe para pulsar nova mensagem
                $('#sw-currents-online tr[data-userid=' + data.userid + ']').addClass('sw-message-new');

                //Emite notificacao externa
                $.swExternalNotification({
                    icon: '/img/logo/speechless-logo-64.png',
                    title: data.username,
                    body: data.message,
                    sound: true
                });
            }
        });

        var contact_list;
        socket.on('contactList', function (data) {
            if (JSON.stringify(contact_list) != JSON.stringify(data)) {
                contact_list = data;
                $('#sw-currents-online tr, #sw-currents-offline tr').remove();
                $.each(data, function (i, val) {

                    var curr_class = "";
                    var curr_local = "";

                    if (val.SPL_USR_EST == 1) {
                        curr_class = "sw-user-offline";
                        curr_local = "#sw-currents-offline";
                    }
                    if (val.SPL_USR_EST == 2) {
                        curr_class = "sw-user-online";
                        curr_local = "#sw-currents-online";
                    }
                    if (val.SPL_USR_EST == 3) {
                        curr_class = "sw-user-occupied";
                        curr_local = "#sw-currents-online";
                    }

                    $('<tr>', {
                        'class': curr_class,
                        'data-target': '#sw-messages',
                        'data-current': '#sw-index',
                        'data-userid': val.SPL_USR_COD,
                        'data-username': val.SPL_USR_NOM
                    }).append($('<td>', {
                        'html': $('<img>', {
                            'src': 'img/user.svg'
                        })
                    })).append($('<td>', {
                        'html': $('<p>', {
                            'html': val.SPL_USR_NOM + '<br /><small>' + val.SPL_USR_MSG + '</small>'
                        })
                    })).appendTo(curr_local);
                });

                $("#sw-currents-online tr").swNavWindows();
            }
        });

        //Envio de formulario de mensagem
        $('form[name=message-form]').submit(function (e) {
            e.preventDefault();
            if ($('input[type=text]', this).val() == '') {
                if ($("body").width() > 600) {
                    $('input[type=text]', this).focus();
                }
                return false;
            } else {
                socket.emit('toServer', {
                    userid: userid,
                    userto: $('#sw-messages').attr('data-userid'),
                    username: username,
                    message: $('form[name=message-form] input[name=message-text]').val(),
                    datetime: moment().locale('pt-br').calendar()
                });
                $('form[name=message-form] input[name=message-text]').val('');
            }
        });
    }

    //Verifica usuario conectado
    $.post("/session", function (data) {
        userid = data.userid;
        username = data.username;
        usermsg = data.usermsg;
        userpic = data.userpic;
        userlast = data.userlast;
        if (userid) {
            //Se autorizado inicia websocket (Socket.IO)
            socketConnection();
            //Se autorizado inicia tela de login
            $.swGoToIndex();
        }
    }).fail(function () {
        $.swOpenDynamicModal({
            title: "<h4>Problemas ao validar sessão</h4>",
            content: "Erro ao tentar identificar a sessão do usuário. Tente novamente mais tarde.",
            buttons: {
                cancel: {
                    btntext: "Ok",
                    btnclass: "btn-link",
                    callback: function (element) {
                        $.swOpenDynamicModal({
                            closeid: $(element).data("id")
                        });
                    }
                }
            }
        });
        $('.modal-box button').focus();
    });

    //Formulario de autenticacao
    $('#sw-auth input[type=text]').focus();
    $('#sw-auth').ajaxForm({
        beforeSubmit: function () {
            $('#sw-auth input').attr('disabled', true);
            if ($('#sw-auth input[type=text]').val() == '') {
                $('#sw-auth input').attr('disabled', false);
                if ($("body").width() > 600) {
                    $('#sw-auth input[type=text]').focus();
                }
                return false;
            } else if ($('#sw-auth input[type=password]').val() == '') {
                $('#sw-auth input').attr('disabled', false);
                if ($("body").width() > 600) {
                    $('#sw-auth input[type=password]').focus();
                }
                return false;
            } else {
                $('preloader').show().transition({
                    opacity: 0
                }, 0).transition({
                    opacity: 1
                }, 300);
            }
        },
        success: function (data) {
            $('preloader').transition({
                opacity: 0
            }, 300, function () {
                $(this).hide();
                if (data.auth_cod == 0) {
                    //Acesso autorizado
                    userid = data.userid;
                    username = data.username;
                    usermsg = data.usermsg;
                    userpic = data.userpic;
                    userlast = data.userlast;
                    //Se autorizado inicia websocket (Socket.IO)
                    socketConnection();
                    //Se autorizado inicia tela de login
                    $.swGoToIndex();
                }
                else if (data.auth_cod == 2) {
                    //Usuario incorreto
                    $('#sw-user-photo').transition({
                        x: -10,
                    }, 100).transition({
                        x: 10,
                    }, 100).transition({
                        x: -10,
                    }, 100).transition({
                        x: 10,
                    }, 100).transition({
                        x: 0,
                    }, 100, function () {
                        $('#sw-auth input').attr('disabled', false);
                        if ($("body").width() > 600) {
                            $('#sw-auth input[type=text]').focus()
                        }
                    });
                }
                else if (data.auth_cod == 3) {
                    //Senha incorreta
                    $('#sw-user-photo').transition({
                        x: -10,
                    }, 100).transition({
                        x: 10,
                    }, 100).transition({
                        x: -10,
                    }, 100).transition({
                        x: 10,
                    }, 100).transition({
                        x: 0,
                    }, 100, function () {
                        $('#sw-auth input').attr('disabled', false);
                        if ($("body").width() > 600) {
                            $('#sw-auth input[type=password]').focus()
                        }
                    });
                }
                else if (data.auth_cod == 1) {
                    //Erro de comunicacao com base de dados
                    $('#sw-user-photo').transition({
                        x: -10,
                    }, 100).transition({
                        x: 10,
                    }, 100).transition({
                        x: -10,
                    }, 100).transition({
                        x: 10,
                    }, 100).transition({
                        x: 0,
                    }, 100, function () {
                        $('#sw-auth input').attr('disabled', false);
                        $.swOpenDynamicModal({
                            title: "<h4>Problemas de comunicação</h4>",
                            content: data.auth_message + '<br /><br /><br />' + data.auth_errcode + ' - ' + data.auth_errinfo,
                            buttons: {
                                cancel: {
                                    btntext: "Ok",
                                    btnclass: "btn-link",
                                    callback: function (element) {
                                        $.swOpenDynamicModal({
                                            closeid: $(element).data("id")
                                        });
                                    }
                                }
                            }
                        });
                        $('.modal-box button').focus();
                    });
                }
            });
        },
        error: function () {
            $('preloader').transition({
                opacity: 0
            }, 300, function () {
                $(this).hide();
                $('#sw-auth input').attr('disabled', false);
                $.swOpenDynamicModal({
                    title: "<h4>Problemas de comunicação</h4>",
                    content: "Não foi possível se comunicar com o servidor. Verifique sua conexão.",
                    buttons: {
                        cancel: {
                            btntext: "Ok",
                            btnclass: "btn-link",
                            callback: function (element) {
                                $.swOpenDynamicModal({
                                    closeid: $(element).data("id")
                                });
                            }
                        }
                    }
                });
                $('.modal-box button').focus();
            });
        }
    });

    //Ao clicar sair
    $("#sw-logout").click(function (e) {
        e.preventDefault();
        $.swOpenDynamicModal({
            title: "<h4>Desconectar?</h4>",
            content: "Você deseja realmente sair?",
            buttons: {
                cancel: {
                    btntext: "Não",
                    btnclass: "btn-link",
                    callback: function (element) {
                        $.swOpenDynamicModal({
                            closeid: $(element).data("id")
                        });
                    }
                },
                confirm: {
                    btntext: "Sim",
                    btnclass: "btn-link",
                    callback: function (element) {
                        $.swOpenDynamicModal({
                            closeid: $(element).data("id")
                        });
                        $.post("/logout", function (data) {
                            if (data.auth_cod) {
                                $.swGoToLogin();
                            }
                        }).fail(function () {
                            $.swOpenDynamicModal({
                                title: "<h4>Problemas ao desconectar</h4>",
                                content: "Erro ao tentar desconectar sua sessão do usuário.",
                                buttons: {
                                    cancel: {
                                        btntext: "Ok",
                                        btnclass: "btn-link",
                                        callback: function (element) {
                                            $.swOpenDynamicModal({
                                                closeid: $(element).data("id")
                                            });
                                        }
                                    }
                                }
                            });
                            $('.modal-box button').focus();
                        });
                    }
                }
            }
        });
    });

});